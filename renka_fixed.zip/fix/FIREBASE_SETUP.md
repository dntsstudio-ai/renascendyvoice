# 🔥 Firebase — Полная инструкция для Renascendi Voice

---

## 1. AUTHENTICATION — Настройка входа

### Где: console.firebase.google.com → проект renascendi-voice → Build → Authentication

**Шаг 1.** Нажми **"Get started"**

**Шаг 2.** Вкладка **"Sign-in method"** → включи **Email/Password**:
- Email/Password → Enable → Save

**Шаг 3.** Вкладка **"Settings"** → **"Authorized domains"**:
- Добавь свой домен GitHub Pages: `твой-логин.github.io`
- `localhost` уже должен быть (для тестирования)

---

## 2. FIRESTORE DATABASE — Создание базы данных

### Где: Build → Firestore Database

**Шаг 1.** Нажми **"Create database"**

**Шаг 2.** Выбери регион: **`eur3 (Europe)`** (ближе к России)

**Шаг 3.** Режим запуска: выбери **"Production mode"** (потом вставим Rules)

**Шаг 4.** Нажми **"Done"**

---

## 3. FIRESTORE — Структура коллекций

Все коллекции создаются **автоматически** при первом использовании сайта.
Но вот что будет создано:

```
releases/                          ← Релизы (аниме, сериалы, фильмы)
  {releaseId}/
    title: string
    genre: string
    year: string
    voiceover: string
    authors: string
    img: string (URL)
    desc: string
    timestamp: number
    episodes: array
    likes: array (uid[])
    dislikes: array (uid[])
    views: number

  {releaseId}/comments/            ← Комментарии к релизу
    {commentId}/
      uid, nick, ava, text, time

users/                             ← Пользователи
  {uid}/
    nickname: string
    email: string
    role: 'user' | 'admin' | 'dub' | 'moderator'
    avatar: string (URL)
    views: number
    subscribers: number
    subscribersList: array (uid[])
    publicBio: string
    publicLink: string
    achievements: array

  {uid}/watchlist/                 ← Избранное и "Буду смотреть"
    {releaseId}/
      type: 'favorite' | 'later'
      relId, title, img, addedAt

  {uid}/viewed/                    ← Просмотренные
    {releaseId}/
      at: number (timestamp)
      title, img

  {uid}/playlists/                 ← Пользовательские плейлисты
    {playlistId}/
      name, desc, img
      pinned: boolean
      createdAt, updatedAt: number

    {playlistId}/items/            ← Релизы в плейлисте
      {releaseId}/
        relId, title, img, addedAt

team/                              ← Члены команды
  {memberId}/
    name, role, img, cat
    bio, social
    order: number
    linkedCardId: string (uid)
    cardPerms: { canEditName, canEditImg }

dubinProjects/                     ← DUB-in проекты
  {projectId}/
    name, genre, status
    raw, hard, soft, voice  (ссылки Drive)
    img, notes
    voiceFiles: array
    createdAt: number

suggestions/                       ← Предложения озвучки
  {id}/
    title, type, link, reason
    senderName, senderEmail, uid
    date, status: 'new'

reports/                           ← Жалобы (от модераторов)
  {id}/
    type, targetUid, targetNick
    reportedBy, reporterUid
    date, status

settings/                          ← Настройки сайта
  privacy/
    text: string                   ← Текст политики конфиденциальности
```

---

## 4. FIRESTORE RULES — Правила безопасности

### Где: Firestore Database → Rules → вставь и нажми Publish

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // ─── Вспомогательные функции ───────────────────────────
    function isAuth() {
      return request.auth != null;
    }

    function isOwner(uid) {
      return isAuth() && request.auth.uid == uid;
    }

    function getUserRole() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
    }

    function isAdmin() {
      return isAuth() && getUserRole() == 'admin';
    }

    function isMod() {
      return isAuth() && (getUserRole() == 'moderator' || isAdmin());
    }

    function isDub() {
      return isAuth() && (getUserRole() == 'dub' || isAdmin());
    }


    // ─── РЕЛИЗЫ ────────────────────────────────────────────
    // Читать могут все (и неавторизованные)
    // Писать — только admin
    match /releases/{releaseId} {
      allow read: if true;
      allow create, update, delete: if isAdmin();

      // Комментарии к релизам
      match /comments/{commentId} {
        allow read: if true;
        // Писать — только авторизованные
        allow create: if isAuth()
          && request.resource.data.uid == request.auth.uid;
        // Удалять — свои или admin
        allow delete: if isAuth()
          && (resource.data.uid == request.auth.uid || isAdmin());
        allow update: if false; // комментарии не редактируются
      }
    }


    // ─── ПОЛЬЗОВАТЕЛИ ──────────────────────────────────────
    match /users/{uid} {
      // Читать профиль — только авторизованные
      allow read: if isAuth();
      // Создать профиль — только себе при регистрации
      allow create: if isOwner(uid);
      // Обновить — себе (базовые поля) или admin
      allow update: if isOwner(uid) || isAdmin();
      // Удалить — только admin
      allow delete: if isAdmin();

      // Вотчлист (избранное, буду смотреть)
      match /watchlist/{relId} {
        allow read, write: if isOwner(uid);
      }

      // Просмотренные
      match /viewed/{relId} {
        allow read, write: if isOwner(uid);
      }

      // Плейлисты
      match /playlists/{playlistId} {
        allow read, write: if isOwner(uid);

        // Элементы плейлиста
        match /items/{itemId} {
          allow read, write: if isOwner(uid);
        }
      }

      // История просмотра серий
      match /watched/{relId} {
        allow read, write: if isOwner(uid);
      }
    }


    // ─── КОМАНДА ────────────────────────────────────────────
    match /team/{memberId} {
      allow read: if true;
      allow create, delete: if isAdmin();
      // Обновить — admin или тот у кого linkedCardId совпадает
      allow update: if isAdmin()
        || (isAuth()
            && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.linkedCardId == memberId);
    }


    // ─── DUB-IN ПРОЕКТЫ ────────────────────────────────────
    match /dubinProjects/{projectId} {
      // Читать — только dub-актёры и выше
      allow read: if isDub();
      // Писать — только admin
      allow create, update, delete: if isAdmin();
    }


    // ─── ПРЕДЛОЖЕНИЯ ОЗВУЧКИ ───────────────────────────────
    match /suggestions/{id} {
      // Создать — любой (авторизованный и нет)
      allow create: if true;
      // Читать — только admin
      allow read: if isAdmin();
      allow update, delete: if isAdmin();
    }


    // ─── ЖАЛОБЫ ────────────────────────────────────────────
    match /reports/{id} {
      allow create: if isMod();
      allow read, update, delete: if isAdmin();
    }


    // ─── НАСТРОЙКИ САЙТА ───────────────────────────────────
    match /settings/{docId} {
      allow read: if true;
      allow write: if isAdmin();
    }

  }
}
```

---

## 5. СОЗДАТЬ ПЕРВОГО АДМИНИСТРАТОРА

После того как зарегистрируешься на сайте:

**Способ 1 — через Firestore Console:**
1. Firestore → `users` → найди свой документ (по UID из Authentication)
2. Нажми на документ → Edit
3. Поле `role` → измени на `"admin"`
4. Save

**Способ 2 — через Authentication:**
1. Authentication → Users → скопируй UID
2. Firestore → users → найди документ с этим UID
3. Измени `role` на `"admin"`

---

## 6. СОЗДАТЬ ИНДЕКСЫ (если Firestore попросит)

Если в консоли браузера появится ошибка **"The query requires an index"** — нажми на ссылку в ошибке. Она откроет Firestore Console и предложит создать нужный индекс автоматически.

Чаще всего нужны индексы для:
- `releases` → по полю `timestamp DESC`
- `users/{uid}/playlists` → по полю `createdAt DESC`
- `dubinProjects` → по полю `createdAt DESC`

---

## 7. ПРОВЕРКА РАБОТЫ

После настройки:
1. Открой сайт
2. Зарегистрируйся (кнопка "Регистрация")
3. Убедись что профиль появился в Firestore → `users`
4. Назначь себе роль `admin`
5. Обнови страницу — должны появиться кнопки администратора

---

## 8. ЧАСТЫЕ ОШИБКИ

| Ошибка | Причина | Решение |
|--------|---------|---------|
| `permission-denied` | Rules запрещают запрос | Проверь Rules, опубликуй заново |
| `auth/unauthorized-domain` | Домен не в списке | Authentication → Settings → Add domain |
| `Missing index` | Нет составного индекса | Нажми ссылку в ошибке → Create index |
| Пустая страница без ошибок | JS модуль не загрузился | Открой DevTools (F12) → Console |
| `CORS` ошибки | Неверный authDomain | Проверь config.js |
